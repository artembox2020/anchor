<link rel="stylesheet" href="/wp-content/plugins/anchors/css/maket.css" />
<?php  
  require_once $_SERVER['DOCUMENT_ROOT']."/wp-config.php";
  global $wpdb;
  $ids=$wpdb->get_col("SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key='footer_link' AND meta_value='1'");
  
?>
<hr/>
<div class="footer-link-block jumbotron">
  <h4>Рекомендуемые посты</h4>    
  <ul>
    <?php foreach($ids as $id): ?>    
      <li><a href="<?= get_permalink($id) ?>"><?= get_post_field('post_title',$id)  ?></a></li>
    <?php endforeach; ?>    
  </ul>
</div>
<hr/>