<?php
/*
  Plugin name: Anchors
  Description: Формирует список ссылок на посты в футере
  Version: 1.0
  Author: Паламарчук А.В.
*/
add_action('admin_menu', function(){	add_menu_page( 'Настройки постов в футере', 'Anchors', 'manage_options', 'footer-options', 'add_posts_to_footer','','4'); 
} );
 function add_posts_to_footer() {
     require_once(__DIR__."/admin_settings.php");
 }
 function puts_script() {
     wp_register_script('jquery-1.7.2',"http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js");
     wp_enqueue_script('jquery-1.7.2');
     wp_register_script('anchors-script',plugins_url("/js/main.js",__FILE__),[],rand(999999999999,999999999999999),true);
     wp_enqueue_script('anchors-script');
 }
  add_action('wp_enqueue_scripts','puts_script');
 ?>