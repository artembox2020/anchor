<link rel="stylesheet" href="/wp-content/plugins/anchors/css/style.css"  />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
<h3 align=center>Управление ссылками футера</h3>
<div class="media-toolbar-secondary">
    <span>Фильтр </span>
    <select id="media-attachment-filters" name="post-type" class="attachment-filters">
        <option value="all">Все посты</option>
        <option value="selected">Помеченные</option>
    </select>
    <br/><br/>
    <div class="anchors-container well well-sm">
    <?php $posts=get_posts(['post_status'=>'publish','limit'=>99999999]);
        foreach($posts as $post):
            $footer_link=get_post_meta($post->ID,'footer_link',true);
    ?>
          <div class="anchors">
            <div class="left"><span id="glyph_<?= $post->ID ?>" class="glyphicon glyphicon-pencil">&nbsp;</span></div>
            <div class="window-edition">
                <span class="glyphicon glyphicon-remove">&nbsp</span>
                <h4>Редактирование ссылки</h4>
                <span>Заголовок</span><br/>
                <input type=hidden value="<?= $post->ID ?>" />
                <input class="post_title" value="<?= $post->post_title ?>" size="32" />
                <br/>
                <span>Якорь</span><br/>
                <input class="post_name" value="<?= $post->post_name ?>" size="32" />
                <br/><br/>
                <button class="btn btn-info okbtn">Применить</button>
            </div>
            <input class="checkbox" type=checkbox <?php if($footer_link) echo "checked=checked";   ?> id="chckbx_<?= $post->ID ?>" />
            <a href="<?= get_permalink($post->ID)  ?>" target=_blank><?= $post->post_title ?></a>
          </div>
    <?php endforeach; ?>    
    </div>
        
</div>
<script>
    jQuery(function($){
        $(".window-edition .glyphicon.glyphicon-remove").click(function(){
            $(this).parent().hide();
        });
        $(".glyphicon.glyphicon-pencil").click(function(){
            $(this).parent().parent().find(".window-edition").toggle();
        });
        $(".okbtn").click(function(){
            var id=$(this).parent().find("input[type=hidden]").val();
            var title=$(this).parent().find(".post_title").val();
            var name=$(this).parent().find(".post_name").val();
            $.ajax({
                url:"/wp-content/plugins/anchors/apis/change_meta.php",
                type:"POST",
                async:false,
                data:{ "id":id,"title":title,"name":name },
                success:function() { location.reload();   }
            });
        });
        $("select.attachment-filters").change(function(){
            $("h4.nothing-notifier").remove();
            if($(this).val()=='all') {
                $(".anchors").css('display','block');
                if($(".anchors").length==0)
                $("<h4 align=center class='nothing-notifier'>").html('Постов не найдено').appendTo(".anchors-container");
            }
            else {
                $(".anchors").hide();
                var cnt=0;
                $(".anchors input[type=checkbox]").each(function(){
                    if($(this).prop('checked'))
                      { $(this).parent().css('display','block'); ++cnt; }
                });
                if(cnt==0) $("<h4 align=center class='nothing-notifier'>").html('Постов не найдено').appendTo(".anchors-container");
            }
        });
        $("input.checkbox").change(function(){
            if($(this).prop('checked')) var checked='1'; else var checked='0';
            $.post("/wp-content/plugins/anchors/apis/change_meta_list.php",{"id":$(this).attr('id').split("_")[1],"checked":checked},function(res){
            });
            
        });
    });
</script>
<?php    ?>