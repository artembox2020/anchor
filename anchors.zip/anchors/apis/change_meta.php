<?php
  include_once($_SERVER['DOCUMENT_ROOT'].'/wp-config.php');
  global $wpdb;
  $wpdb->update("{$wpdb->prefix}posts",['post_title'=>$_POST['title'],'post_name'=>$_POST['name']],['ID'=>$_POST['id']]);