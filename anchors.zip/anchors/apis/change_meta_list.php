<?php 
  echo $_POST['id'].'good'.$_POST['checked']."<br/>";
  include_once($_SERVER['DOCUMENT_ROOT'].'/wp-config.php');
  global $wpdb;
  $value=$wpdb->get_col($wpdb->prepare("SELECT meta_value FROM {$wpdb->prefix}postmeta WHERE post_id=%d AND meta_key='footer_link'",[$_POST['id']]));
  //echo $_POST['checked']?'1':'0';
  if(!is_array($value) || count($value)==0)
    $wpdb->insert("{$wpdb->prefix}postmeta",['post_id'=>$_POST['id'],'meta_key'=>'footer_link','meta_value'=>$_POST['checked']?'1':'0']);
  else
    $wpdb->update("{$wpdb->prefix}postmeta",['meta_value'=>$_POST['checked']?'1':'0'],['meta_key'=>'footer_link','post_id'=>$_POST['id']]);
?>